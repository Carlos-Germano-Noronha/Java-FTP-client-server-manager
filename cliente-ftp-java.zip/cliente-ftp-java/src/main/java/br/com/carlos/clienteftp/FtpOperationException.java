package br.com.carlos.clienteftp;

public class FtpOperationException extends Exception {
    public FtpOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}