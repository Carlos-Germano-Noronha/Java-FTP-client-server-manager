import java.util.Scanner;
public class App {

    public static void main(String[] args) {
        FtpService ftpService = new FtpService();
        Scanner scanner = new Scanner(System.in);

        // Detalhes do seu servidor de teste
        String host = "127.0.0.1";
        String usuario = "carlos";
        String senha = "2558";

        try {
            if (!ftpService.connect(host, usuario, senha)) {
                System.out.println("Não foi possível conectar. Encerrando o programa.");
                return;
            }
            System.out.println("Conexão estabelecida.\n");

            int escolha = -1;
            while (escolha != 0) {
                System.out.println("--- MENU FTP ---");
                System.out.println("1 - Listar arquivos e pastas");
                System.out.println("2 - Fazer Upload de Arquivo");
                System.out.println("3 - Fazer Download de Arquivo");
                System.out.println("4 - Criar Diretório");
                System.out.println("5 - Remover Arquivo");
                System.out.println("6 - Remover Diretório");
                System.out.println("7 - Renomear Arquivo/Diretório");
                System.out.println("8 - Mudar de Diretório"); // <-- NOVA OPÇÃO
                System.out.println("0 - Sair");
                System.out.print("Escolha uma opção: ");

                escolha = scanner.nextInt();
                scanner.nextLine(); // Consome a quebra de linha

                switch (escolha) {
                    case 1: {
                        // ... (o código do case 1 continua o mesmo)
                        System.out.println("\nListando arquivos...");
                        String[] nomesArquivos = ftpService.getFilesList();
                        if (nomesArquivos.length == 0) {
                            System.out.println("Nenhum arquivo encontrado ou diretório vazio.");
                        } else {
                            for (String nome : nomesArquivos) {
                                System.out.println("- " + nome);
                            }
                        }
                        System.out.println("---------------------\n");
                        break;
                    }
                    case 2: {// <-- NOVO CASE PARA UPLOAD
                        System.out.print("Digite o caminho completo do arquivo local (ex: C:/temp/teste.txt): ");
                        String localPath = scanner.nextLine();

                        System.out.print("Digite o nome que o arquivo terá no servidor (ex: enviado.txt): ");
                        String remoteName = scanner.nextLine();

                        boolean sucesso = ftpService.uploadFile(localPath, remoteName);
                        if (sucesso) {
                            System.out.println("Upload concluído com sucesso!");
                        } else {
                            System.err.println("Ocorreu uma falha no upload.");
                        }
                        System.out.println("---------------------\n");
                        break;
                    }
                    case 3: // <-- NOVO CASE PARA DOWNLOAD
                        System.out.print("Digite o nome do arquivo no servidor para baixar: ");
                        String remoteFile = scanner.nextLine();

                        System.out.print("Digite o caminho completo para salvar o arquivo localmente (ex: C:/downloads/recebido.txt): ");
                        String localFile = scanner.nextLine();

                        boolean sucesso = ftpService.downloadFile(remoteFile, localFile);
                        if (sucesso) {
                            System.out.println("Download concluído com sucesso!");
                        } else {
                            System.err.println("Ocorreu uma falha no download.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 4:// <-- NOVO CASE PARA CRIAR DIRETÓRIO
                        System.out.print("Digite o nome do novo diretório: ");
                        String dirName = scanner.nextLine();

                        sucesso = ftpService.createDirectory(dirName);
                        if (sucesso) {
                            System.out.println("Operação finalizada.");
                        } else {
                            System.err.println("Não foi possível criar o diretório.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 5: // <-- NOVO CASE PARA REMOVER ARQUIVO
                        System.out.print("Digite o nome do arquivo a ser removido: ");
                        String fileName = scanner.nextLine();

                        sucesso = ftpService.deleteFile(fileName);
                        if (sucesso) {
                            System.out.println("Operação finalizada.");
                        } else {
                            System.err.println("Não foi possível remover o arquivo.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 6: // <-- NOVO CASE PARA REMOVER DIRETÓRIO
                        System.out.print("Digite o nome do diretório a ser removido: ");
                        String dirToRemove = scanner.nextLine();

                        sucesso = ftpService.removeDirectory(dirToRemove);
                        if (sucesso) {
                            System.out.println("Operação finalizada.");
                        } else {
                            System.err.println("Não foi possível remover o diretório.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 7: // <-- NOVO CASE PARA RENOMEAR
                        System.out.print("Digite o nome atual do arquivo/diretório: ");
                        String fromName = scanner.nextLine();

                        System.out.print("Digite o NOVO nome: ");
                        String toName = scanner.nextLine();

                        sucesso = ftpService.rename(fromName, toName);
                        if (sucesso) {
                            System.out.println("Operação finalizada.");
                        } else {
                            System.err.println("Não foi possível renomear.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 8: // <-- NOVO CASE PARA MUDAR DE DIRETÓRIO
                        System.out.print("Digite o nome do diretório para entrar (ou '..' para subir um nível): ");
                        String dirToEnter = scanner.nextLine();

                        sucesso = ftpService.changeDirectory(dirToEnter);
                        if (!sucesso) {
                            System.err.println("Não foi possível entrar no diretório.");
                        }
                        System.out.println("---------------------\n");
                        break;

                    case 0:
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.out.println("Opção inválida!\n");
                        break;
                }
            }
            System.out.println("\nGerando relatório para envio de e-mail...");
            String relatorioFinal = ftpService.getFullDirectoryListing();
            System.out.println(relatorioFinal); // Mostra o relatório completo na tel

            System.out.print("Digite o e-mail do destinatário: ");
            String emailDestino = scanner.nextLine();

            System.out.print("Digite o caminho completo do arquivo para anexar: ");
            String caminhoAnexo = scanner.nextLine();

            EmailService emailService = new EmailService();
            emailService.sendReportEmail(
                    emailDestino,
                    "EC1 - Relatório do Servidor FTP", // Assunto do e-mail
                    relatorioFinal,                          // Corpo do e-mail
                    caminhoAnexo                        // Anexo
            );

        } finally {
            // 3. Desconecta APÓS sair do loop
            scanner.close(); // Fecha o leitor de entrada
            System.out.println("Encerrando a conexão com o servidor.");
            ftpService.disconnect();
        }
    }
}