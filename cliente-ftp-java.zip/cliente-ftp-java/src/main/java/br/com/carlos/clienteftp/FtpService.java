import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class FtpService {

    private final FTPClient ftpClient;

    public FtpService() {
        this.ftpClient = new FTPClient();
    }

    /**
     * Conecta e faz login em um servidor FTP.
     * @param host Endereço do servidor
     * @param user Nome de usuário
     * @param pass Senha
     * @return true se a conexão for bem-sucedida, false caso contrário.
     */
    public boolean connect(String host, String user, String pass) {
        try {
            ftpClient.connect(host);
            int replyCode = ftpClient.getReplyCode();

            if (!FTPReply.isPositiveCompletion(replyCode)) {
                System.err.println("Falha na conexão com o servidor. Código: " + replyCode);
                return false;
            }

            boolean success = ftpClient.login(user, pass);
            if (!success) {
                System.err.println("Usuário ou senha inválidos.");
                return false;
            }

            ftpClient.enterLocalPassiveMode();

            return true;

        } catch (IOException e) {
            System.err.println("Erro de IO: " + e.getMessage());
            return false;
        }
    }

    /**
     * Desconecta do servidor FTP.
     */
    public void disconnect() {
        if (this.ftpClient != null && this.ftpClient.isConnected()) {
            try {
                this.ftpClient.logout();
                this.ftpClient.disconnect();
            } catch (IOException e) {
                System.err.println("Erro ao desconectar: " + e.getMessage());
            }
        }
    }
    /**
     * Lista os nomes dos arquivos e diretórios no caminho atual.
     * @return Um array de Strings com os nomes, ou um array vazio se houver erro.
     */
    public String[] getFilesList() {
        try {
            // Usa o método da biblioteca que executa o comando LIST do FTP
            FTPFile[] files = ftpClient.listFiles();

            // Converte o array de FTPFile para um array de String com os nomes
            String[] fileNames = new String[files.length];
            for (int i = 0; i < files.length; i++) {
                fileNames[i] = files[i].getName();
            }
            return fileNames;

        } catch (IOException e) {
            System.err.println("Erro ao listar arquivos: " + e.getMessage());
            return new String[0]; // Retorna um array vazio em caso de erro
        }
    }
    /**
     * Faz o upload de um arquivo local para o servidor FTP.
     * @param localFilePath O caminho completo do arquivo no seu computador (ex: C:/temp/meu_arquivo.txt)
     * @param remoteFileName O nome que o arquivo terá no servidor (ex: relatorio.txt)
     * @return true se o upload for bem-sucedido, false caso contrário.
     */
    public boolean uploadFile(String localFilePath, String remoteFileName) {
        File localFile = new File(localFilePath);

        // 1. Verifica se o caminho existe
        if (!localFile.exists()) {
            System.err.println("Arquivo local não encontrado: " + localFilePath);
            return false;
        }

        // 2. NOVA VERIFICAÇÃO: Garante que não é um diretório
        if (localFile.isDirectory()) {
            System.err.println("Erro: O caminho fornecido é um diretório, não um arquivo. Por favor, forneça o caminho de um arquivo.");
            return false;
        }

        System.out.println("Iniciando upload do arquivo: " + localFile.getName());

        try (InputStream inputStream = new FileInputStream(localFile)) {
            boolean done = ftpClient.storeFile(remoteFileName, inputStream);
            if (done) {
                System.out.println("Arquivo enviado com sucesso.");
                return true;
            } else {
                System.err.println("Falha ao enviar o arquivo.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro durante o upload: " + e.getMessage());
            return false;
        }
    }
    /**
     * Faz o download de um arquivo do servidor FTP para o computador local.
     * @param remoteFileName O nome do arquivo no servidor (ex: relatorio.txt)
     * @param localFilePath O caminho completo onde o arquivo será salvo localmente (ex: C:/downloads/arquivo_recebido.txt)
     * @return true se o download for bem-sucedido, false caso contrário.
     */
    public boolean downloadFile(String remoteFileName, String localFilePath) {
        System.out.println("Iniciando download do arquivo: " + remoteFileName);

        // Usamos um try-with-resources para garantir que o OutputStream seja fechado.
        try (OutputStream outputStream = new FileOutputStream(localFilePath)) {
            // O método retrieveFile faz o trabalho de baixar o arquivo.
            boolean success = ftpClient.retrieveFile(remoteFileName, outputStream);

            if (success) {
                System.out.println("Arquivo baixado com sucesso para: " + localFilePath);
                return true;
            } else {
                System.err.println("Falha ao baixar o arquivo.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro durante o download: " + e.getMessage());
            return false;
        }
    }

    /**
     * Cria um novo diretório no caminho atual do servidor FTP.
     * @param dirPath O nome do diretório a ser criado.
     * @return true se o diretório for criado com sucesso, false caso contrário.
     */
    public boolean createDirectory(String dirPath) {
        try {
            // O método makeDirectory executa o comando MKD no servidor.
            boolean success = ftpClient.makeDirectory(dirPath);
            if (success) {
                System.out.println("Diretório '" + dirPath + "' criado com sucesso.");
                return true;
            } else {
                System.err.println("Falha ao criar o diretório. Pode ser que já exista ou falta de permissão.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro ao tentar criar diretório: " + e.getMessage());
            return false;
        }
    }
    /**
     * Remove um arquivo do diretório atual no servidor FTP.
     * @param filePath O nome do arquivo a ser removido.
     * @return true se o arquivo for removido com sucesso, false caso contrário.
     */
    public boolean deleteFile(String filePath) {
        try {
            // O método deleteFile executa o comando DELE no servidor.
            boolean deleted = ftpClient.deleteFile(filePath);
            if (deleted) {
                System.out.println("Arquivo '" + filePath + "' removido com sucesso.");
                return true;
            } else {
                System.err.println("Falha ao remover o arquivo. Verifique se o arquivo existe e se você tem permissão.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro ao tentar remover o arquivo: " + e.getMessage());
            return false;
        }
    }
    /**
     * Remove um diretório vazio do servidor FTP.
     * @param dirPath O nome do diretório a ser removido.
     * @return true se o diretório for removido com sucesso, false caso contrário.
     */
    public boolean removeDirectory(String dirPath) {
        try {
            // O método removeDirectory executa o comando RMD no servidor.
            boolean removed = ftpClient.removeDirectory(dirPath);
            if (removed) {
                System.out.println("Diretório '" + dirPath + "' removido com sucesso.");
                return true;
            } else {
                System.err.println("Falha ao remover o diretório. Verifique se ele existe, se está vazio e se você tem permissão.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro ao tentar remover o diretório: " + e.getMessage());
            return false;
        }
    }
    /**
     * Renomeia um arquivo ou diretório no servidor FTP.
     * @param fromName O nome atual do arquivo/diretório.
     * @param toName O novo nome para o arquivo/diretório.
     * @return true se a operação for bem-sucedida, false caso contrário.
     */
    public boolean rename(String fromName, String toName) {
        try {
            // O método rename executa os comandos RNFR e RNTO no servidor.
            boolean renamed = ftpClient.rename(fromName, toName);
            if (renamed) {
                System.out.println("Item renomeado com sucesso de '" + fromName + "' para '" + toName + "'.");
                return true;
            } else {
                System.err.println("Falha ao renomear. Verifique se o item de origem existe e se você tem permissão.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro ao tentar renomear: " + e.getMessage());
            return false;
        }
    }
    public String getFullDirectoryListing() {
        StringBuilder reportBuilder = new StringBuilder("Relatório de Conteúdo do Servidor FTP:\n");
        try {
            // Começa a listagem a partir do diretório raiz
            listDirectoryRecursive("/", 0, reportBuilder);
        } catch (IOException e) {
            reportBuilder.append("\nErro ao gerar o relatório completo: " + e.getMessage());
        }
        return reportBuilder.toString();
    }
    /**
     * Método auxiliar privado e recursivo para listar o conteúdo dos diretórios.
     * @param parentDir O diretório a ser listado.
     * @param indentLevel O nível de indentação para formatação.
     * @param reportBuilder O objeto para construir a string do relatório.
     * @throws IOException
     */
    private void listDirectoryRecursive(String parentDir, int indentLevel, StringBuilder reportBuilder) throws IOException {
        String indent = "  ".repeat(indentLevel); // Cria a indentação (espaços)

        // Entra no diretório especificado
        if (!ftpClient.changeWorkingDirectory(parentDir)) {
            return; // Não foi possível entrar no diretório, sai da função
        }

        FTPFile[] files = ftpClient.listFiles();
        if (files != null && files.length > 0) {
            for (FTPFile file : files) {
                if (file.isDirectory()) {
                    reportBuilder.append(indent).append("DIR:  ").append(file.getName()).append("/\n");
                    // Chamada recursiva: a função chama a si mesma para a subpasta
                    listDirectoryRecursive(file.getName(), indentLevel + 1, reportBuilder);
                } else {
                    reportBuilder.append(indent).append("FILE: ").append(file.getName()).append("\n");
                }
            }
        }

        // Crucial: volta para o diretório pai após listar o conteúdo do diretório atual
        ftpClient.changeToParentDirectory();
    }
    /**
     * Muda o diretório de trabalho atual no servidor FTP.
     * @param dirPath O nome do diretório para o qual se deseja navegar. Use ".." para subir um nível.
     * @return true se a operação for bem-sucedida, false caso contrário.
     */
    public boolean changeDirectory(String dirPath) {
        try {
            // O método changeWorkingDirectory executa o comando CWD no servidor.
            boolean success = ftpClient.changeWorkingDirectory(dirPath);
            if (success) {
                System.out.println("Navegou para o diretório: " + ftpClient.printWorkingDirectory());
                return true;
            } else {
                System.err.println("Falha ao mudar de diretório. Verifique se o diretório existe.");
                return false;
            }
        } catch (IOException e) {
            System.err.println("Erro ao tentar mudar de diretório: " + e.getMessage());
            return false;
        }
    }
}